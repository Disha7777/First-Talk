package com.deaf.firsttalk;

import android.view.View;

public interface RecycleItemClickListener {
    void onClick(View view, int position);
}
